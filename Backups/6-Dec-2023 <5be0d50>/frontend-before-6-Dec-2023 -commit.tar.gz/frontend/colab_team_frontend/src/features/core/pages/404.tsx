export function Component() {
  return <div>404 NOT FOUND</div>;
}

import AppLink from "~components/Link";

export function Component() {
  return (
    <div>
      Your email has been successfully verified.
      <AppLink href="/login">Go to login page</AppLink>
    </div>
  );
}

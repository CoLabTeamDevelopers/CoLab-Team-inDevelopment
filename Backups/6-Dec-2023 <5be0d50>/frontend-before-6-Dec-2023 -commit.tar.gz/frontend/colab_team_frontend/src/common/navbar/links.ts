export const leftNavLinks = [
  { label: "Home", href: "/" },
  { label: "Projects", href: "/projects" },
  { label: "Workspace", href: "/workspace" },
  { label: "Discuss", href: "/discuss" },
  { label: "About", href: "/about" },
];

export const rightNavLinks = [
  { label: "Profile", href: "/profile" },
  { label: "Create", href: "/projects/create" },
  { label: "Requests", href: "/profile/requests" },
  { label: "My Projects", href: "/profile/projects" },
];
